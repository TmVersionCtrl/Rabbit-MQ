package com.workingWithMQ.Basics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitMqProjectBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
