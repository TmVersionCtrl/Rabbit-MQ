package com.workingWithMQ.Basics;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@EnableScheduling
@SpringBootApplication
public class RabbitMqProjectBasicApplication {

	@Autowired
	private AmqpTemplate rabbitAmqpTemplate;
	
	private static int val = 0;
	
//	@Scheduled(fixedDelay = 2000)
//	private void sendMessage() {
//		log.info("Sending Message:->"+ val++);
//		rabbitAmqpTemplate.convertAndSend("queue.basic","queue.bind.basic","Message: "+val);
//	}
//	
	@Scheduled(fixedDelay = 3000)
	private void consumeMessage() {
		String receiveAndConvert = (String) rabbitAmqpTemplate.receiveAndConvert("temp.basic.queue");
		log.info("Consuming message:->"+receiveAndConvert);
	}
	
	public static void main(String[] args) {
		SpringApplication.run(RabbitMqProjectBasicApplication.class, args);
	}

}
