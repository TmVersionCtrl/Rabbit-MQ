package com.workingWithMQ.Basics;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {
	
	@Bean
	Queue queue() {
		return new Queue("temp.basic.queue",true,false,false);
	}

	@Bean
	DirectExchange directExchange() {
		return new DirectExchange("queue.basic");
	}

	@Bean
	Binding binding(Queue queue,DirectExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange).with("queue.bind.basic");
	}
	
	@Bean
	CachingConnectionFactory cachingConnectionFactory() {
		final CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory();
		cachingConnectionFactory.setVirtualHost("/");
		cachingConnectionFactory.setHost("localhost");
		cachingConnectionFactory.setUsername("guest");
		cachingConnectionFactory.setPassword("guest");
		cachingConnectionFactory.setConnectionNameStrategy(c->"MY_CONNECTION_NAME");
		return cachingConnectionFactory;
	}	
}
